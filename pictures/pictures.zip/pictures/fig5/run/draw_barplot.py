from sklearn.preprocessing import MinMaxScaler
import numpy as np

rlipp_y = []
rlipp_x = []
top_data = open("../data/final_top_term_rlipp.txt")
index = 0
for line in top_data:
    index += 1
    line = line.rstrip().split()
    rlipp_y.append(float(line[1]))
    rlipp_x.append(str(index - 1))
top_data.close()

print("rlipp_y: ", rlipp_y)
print("rlipp_x: ", rlipp_x)

rlipp_y_np = []
for i in range(len(rlipp_y)):
    if i == 0:
        rlipp_y[i] = 100
    temp = []
    temp.append(rlipp_y[i])
    rlipp_y_np.append(temp)

min_max_scaler = MinMaxScaler(feature_range=(10, 100))
rlipp_y_np = min_max_scaler.fit_transform(np.array(rlipp_y_np))
rlipp_y_np = np.around(rlipp_y_np, 5)

rlipp_y_bar = []
for i in range(len(rlipp_y_np)):
    rlipp_y_bar.append(rlipp_y_np[i][0])
print("minmax_rlipp_y_bar: ", rlipp_y_bar)

import matplotlib.pyplot as plt

rlipp_y_bar = rlipp_y_bar[0:208]

plt.figure(figsize=(10, 12), dpi=100)
# plt.plot([0.0, 684], [0.0, 0.0], color='black', linewidth=1, label="best line")

red_list = [0, 6, 12, 15, 26, 37, 48, 49, 52, 56, 68, 69, 72, 73, 75, 78, 82, 85, 95, 100, 102, 122, 123, 126, 135, 136, 139, 156, 180, 190, 192, 198, 205, 206]
color_list = ['navy'] * len(rlipp_y_bar)
for i in range(len(color_list)):
    if i in red_list:
        color_list[i] = 'red'

plt.bar(range(len(rlipp_y_bar)), rlipp_y_bar, width=1.5, color=color_list)
plt.xlabel(u'Top 10% of subsystems ', fontsize=35, labelpad=18.5)
plt.ylabel(u'Importance for paclitaxel response\n(RLIPP score) ', fontsize=35, labelpad=18.5)

plt.xticks([])
plt.yticks([20, 80], [20, 80], fontsize=35)
plt.tick_params(width=2)

ax=plt.gca()
ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2)
ax.spines['right'].set_linewidth(0)
ax.spines['top'].set_linewidth(0)

plt.savefig('../img/barplot.png', bbox_inches='tight')


"""
GO:2000377 regulation of reactive oxygen species metabolic process
GO:0031329 regulation of cellular catabolic process
GO:1901615 organic hydroxy compound metabolic process
GO:0019219 regulation of nucleobase-containing compound metabolic process
GO:0034655 nucleobase-containing compound catabolic process
GO:0016311 dephosphorylation
GO:0006396 mitochondrial RNA processing
GO:1901135 carbohydrate derivative metabolic process
GO:0071702 organic substance transport
"""
