import numpy as np
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt


cell_mutation = np.genfromtxt("../data/cell2mutation_update.txt", delimiter=',')
cell_exp = np.genfromtxt("../data/cell2exp_update.txt", delimiter=',')

min_max_scaler = MinMaxScaler()
exp_result = min_max_scaler.fit_transform(cell_exp)
cell_exp = np.around(exp_result, 5)
cell_features = cell_mutation + cell_exp

cell_features = cell_features[:, 287:288]

# print(cell_features)
# print(len(cell_features))
# print(len(cell_features[0]))
# print("cell_mutation_BRAF: ", cell_mutation[:,287:288])
# print("cell_exp_BRAF: ", cell_exp[:,287:288])
# print("cell_features: ", cell_features[:, 287:288])

index_list = []
index = open("../data/selumetinib_index.txt")
for line in index:
    line = line.rstrip().split()
    index_list.append(int(line[0]))
index.close()

mu_count = 0
cell_list = []
for x in range(len(cell_features)):
    if cell_features[x][0] >= 0.6 and x in index_list:
        mu_count += 1
        cell_list.append(x)
print("cell_list: ", cell_list)
print("cell_list_len: ", len(cell_list))
print("mu_count: ", mu_count)

pc1 = []
pc2 = []
pc1_file = open("../data/pc1_common.txt")
for line in pc1_file:
    line = line.rstrip().split()
    pc1.append(float(line[0]))
pc1_file.close()

pc2_file = open("../data/pc2_common.txt")
for line in pc2_file:
    line = line.rstrip().split()
    pc2.append(float(line[0]))
pc2_file.close()

pc1_exist = []
pc1_noexist = []
for x in range(len(pc1)):
    if x in cell_list:
        pc1_exist.append(pc1[x])
    else:
        pc1_noexist.append(pc1[x])

pc2_exist = []
pc2_noexist = []
for x in range(len(pc2)):
    if x in cell_list:
        pc2_exist.append(pc2[x])
    else:
        pc2_noexist.append(pc2[x])

# print(len(pc1_exist))
# print(len(pc1_noexist))
# print(len(pc2_exist))
# print(len(pc2_noexist))

plt.figure(figsize=(15, 20), dpi=100)
# plt.plot([-0.8, 1.0], [-0.8, 1.0], color='black', linewidth=2, label="best line")

area1 = [300] * len(pc1_exist)
area2 = [150] * len(pc1_noexist)

# area1 = [50] * len(pc1_exist)
# area2 = [50] * len(pc1_noexist)

# label = ['red'] * 58 + ['lime'] * 626

plt.scatter(pc1_noexist, pc2_noexist, label="train data", s=area2, c="#808080")
plt.scatter(pc1_exist, pc2_exist, label="train data", s=area1, c="red", cmap='viridis')

plt.xlabel(u'Genotype embedding(PC1) ', fontsize=55, labelpad=18.5)
plt.ylabel(u'Genotype embedding(PC2) ', fontsize=55, labelpad=28.5)

plt.xticks([-20, 20, 60], [-20, 20, 60], fontsize=35)
plt.yticks([-40, 0, 40, 60], [-40, 0, 40,60], fontsize=35)

# plt.xticks([-0.5, 0.0, 0.5], [-0.5, 0.0, 0.5], fontsize=35)
# plt.yticks([-0.5, 0.0, 0.5], [-0.5, 0.0, 0.5], fontsize=35)

plt.xticks([])  # 去x坐标刻度
plt.yticks([])  # 去y坐标刻度


# data = np.random.random([10, 10])
# cb1 = plt.colorbar(fraction=0.05, pad=0.03, orientation="horizontal")
# cb1 = plt.colorbar(fraction=0.03, pad=0.03)

# tick_locator = ticker.MaxNLocator(nbins=4)  # colorbar上的刻度值个数
# cb1.locator = tick_locator
# cb1.set_ticks([0.0, 0.4, 0.8, 1.2])
# cb1.update_ticks()


ax=plt.gca()
ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2)
ax.spines['right'].set_linewidth(0)
ax.spines['top'].set_linewidth(0)

plt.text(-30, 55, r'n={}'.format(len(pc1_exist)),
         family='Times New Roman',  # 标注文本字体
         fontsize=63,  # 文本大小
         # fontweight='bold',  # 字体粗细
         color='black'  # 文本颜色
         )

plt.savefig('../img/se_point.png', bbox_inches='tight')


