import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
from sklearn.preprocessing import MinMaxScaler


pc1 = []
pc2 = []
pc1_file = open("../data/pc1_common.txt")
for line in pc1_file:
    line = line.rstrip().split()
    pc1.append(float(line[0]))
pc1_file.close()

pc2_file = open("../data/pc2_common.txt")
for line in pc2_file:
    line = line.rstrip().split()
    pc2.append(float(line[0]))
pc2_file.close()

# print("pc1: ", pc1)
# print("pc2: ", pc2)


pre_list = []
pre = open("../data/selumetinib_new.predict")
for line in pre:
    line = line.rstrip().split()
    pre_list.append(float(line[0]))
pre.close()

pre_np = []
for i in range(len(pre_list)):
    temp = []
    temp.append(pre_list[i])
    pre_np.append(temp)

print(pre_np)
min_max_scaler = MinMaxScaler(feature_range=(0.0, 1.0))
pre_result = min_max_scaler.fit_transform(np.array(pre_np))
pre_result = np.around(pre_result, 5)
# print(pre_result)
pre_list = list(pre_result)

index_list = []
index = open("../data/selumetinib_index.txt")
for line in index:
    line = line.rstrip().split()
    index_list.append(int(line[0]))
index.close()

# index_list = list(set(index_list))
# support = []
# for i in index_list:
#     support.append(index_list.index(i))
# support = list(set(support))

# print("support: ", support)
# print(len(support))

for i in range(len(pre_list)):
    if 0.6 <= pre_list[i] <= 0.8:
        pre_list[i] = pre_list[i] / 4

print("pre_list: ", pre_list)
print("pre_list_len: ", len(pre_list))
print("index_list: ", index_list)

pc1_exist = []
pc1_noexist = []
for x in range(len(pc1)):
    if x in index_list:
        pc1_exist.append(pc1[x])
    else:
        pc1_noexist.append(pc1[x])

pc2_exist = []
pc2_noexist = []
for x in range(len(pc2)):
    if x in index_list:
        pc2_exist.append(pc2[x])
    else:
        pc2_noexist.append(pc2[x])

# print("总药物：", len(pc1))
# print("反应药物：", len(index_list))
#
# print("pc1_exist: ", pc1_exist)
# print(len(pc1_exist))
# print(len(pc1_noexist))
# print("pc1_noexist: ", pc1_noexist)
#
# print("pc2_exist: ", pc2_exist)
# print(len(pc2_exist))
# print(len(pc2_noexist))
# print("pc2_noexist: ", pc2_noexist)


plt.figure(figsize=(15, 20), dpi=100)
# plt.plot([-0.8, 1.0], [-0.8, 1.0], color='black', linewidth=2, label="best line")
area1 = [300] * 744
area2 = [300] * 198

# label = ['red'] * 58 + ['lime'] * 626

plt.scatter(pc1_noexist, pc2_noexist, label="train data", s=area2, c="#808080")
plt.scatter(pc1_exist, pc2_exist, label="train data", s=area1, c=pre_list, cmap='viridis')

plt.xlabel(u'Genotype embedding(PC1) ', fontsize=55, labelpad=18.5)
plt.ylabel(u'Genotype embedding(PC2) ', fontsize=55, labelpad=28.5)

plt.xticks([-20, 20, 60], [-20, 20, 60], fontsize=35)
plt.yticks([-40, 0, 40, 60], [-40, 0, 40,60], fontsize=35)

# plt.xticks([-0.5, 0.0, 0.5], [-0.5, 0.0, 0.5], fontsize=35)
# plt.yticks([-0.5, 0.0, 0.5], [-0.5, 0.0, 0.5], fontsize=35)

plt.xticks([])  # 去x坐标刻度
plt.yticks([])  # 去y坐标刻度


# data = np.random.random([10, 10])
# cb1 = plt.colorbar(fraction=0.05, pad=0.03, orientation="horizontal")
# cb1 = plt.colorbar(fraction=0.03, pad=0.03)

# tick_locator = ticker.MaxNLocator(nbins=4)  # colorbar上的刻度值个数
# cb1.locator = tick_locator
# cb1.set_ticks([0.0, 0.4, 0.8, 1.2])
# cb1.update_ticks()


ax=plt.gca()
ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2)
ax.spines['right'].set_linewidth(0)
ax.spines['top'].set_linewidth(0)

plt.text(-30, 55, r'n={}'.format(len(pc1_exist)),
         family='Times New Roman',  # 标注文本字体
         fontsize=63,  # 文本大小
         # fontweight='bold',  # 字体粗细
         color='black'  # 文本颜色
         )

plt.savefig('../img/se_pc.png', bbox_inches='tight')

