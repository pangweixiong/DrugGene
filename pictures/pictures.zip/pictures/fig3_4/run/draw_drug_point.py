import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import MinMaxScaler


pc1 = []
pc2 = []
pc1_file = open("../data/pc1_drug_update.txt")
for line in pc1_file:
    line = line.rstrip().split()
    pc1.append(float(line[0]))
pc1_file.close()

pc2_file = open("../data/pc2_drug_update.txt")
for line in pc2_file:
    line = line.rstrip().split()
    pc2.append(float(line[0]))
pc2_file.close()

print("pc1: ", pc1)
print("pc2: ", pc2)
print(len(pc1))
print(len(pc2))


# pc1_np = []
# for i in range(len(pc1)):
#     temp = []
#     temp.append(pc1[i])
#     pc1_np.append(temp)
#
# print(pc1_np)
# min_max_scaler = MinMaxScaler(feature_range=(0.0, 1.0))
# pc1_result = min_max_scaler.fit_transform(np.array(pc1_np))
# pc1_result = np.around(pc1_result, 5)
# pc1 = list(pc1_result)
#
# pc2_np = []
# for i in range(len(pc2)):
#     temp = []
#     temp.append(pc2[i])
#     pc2_np.append(temp)
#
# print(pc2_np)
# min_max_scaler = MinMaxScaler(feature_range=(0.0, 1.0))
# pc2_result = min_max_scaler.fit_transform(np.array(pc2_np))
# pc2_result = np.around(pc2_result, 5)
# pc2 = list(pc2_result)


"""
BRAF: Dabrafenib delete
      Selumetinib * 4
EGFR: Afatinib
      Erlotinib delete
BRD4: JQ1 * 3
PARP: Olaparib
      veliparib
FGFR: 

"""
target_BRAF = [353, 354, 604, 589, 381, 250]
target_EGFR = [506, 612]
target_BRD4 = [243, 469, 660]
target_PARP = [119, 227]
# target_class = [255, 354, 353, 506, 612, 43, 243, 340, 565, 119]
target_class = target_BRAF + target_EGFR + target_BRD4 + target_PARP
target_class = sorted(target_class)
print(target_class)

pc1_exist_BRAF = []
pc1_exist_EGFR = []
pc1_exist_BRD4 = []
pc1_exist_PARP = []
pc1_noexist = []
for x in range(len(pc1)):
    if x in target_BRAF:
        pc1_exist_BRAF.append(pc1[x])
    elif x in target_EGFR:
        pc1_exist_EGFR.append(pc1[x])
    elif x in target_BRD4:
        pc1_exist_BRD4.append(pc1[x])
    elif x in target_PARP:
        pc1_exist_PARP.append(pc1[x])
    else:
        pc1_noexist.append(pc1[x])

pc2_exist_BRAF = []
pc2_exist_EGFR = []
pc2_exist_BRD4 = []
pc2_exist_PARP = []
pc2_noexist = []
for x in range(len(pc2)):
    if x in target_BRAF:
        pc2_exist_BRAF.append(pc2[x])
    elif x in target_EGFR:
        pc2_exist_EGFR.append(pc2[x])
    elif x in target_BRD4:
        pc2_exist_BRD4.append(pc2[x])
    elif x in target_PARP:
        pc2_exist_PARP.append(pc2[x])
    else:
        pc2_noexist.append(pc2[x])

plt.figure(figsize=(15, 20), dpi=100)

area1 = [150] * (684 - len(target_class))
area2_BRAF = [500] * len(target_BRAF)
area2_EGFR = [500] * len(target_EGFR)
area2_BRD4 = [500] * len(target_BRD4)
area2_PARP = [500] * len(target_PARP)
target_color1 = ["red"] * len(target_BRAF)
target_color2 = ["blue"] * len(target_EGFR)
target_color3 = ["fuchsia"] * len(target_BRD4)
target_color4 = ["green"] * len(target_PARP)

plt.scatter(pc1_noexist, pc2_noexist, label="train data", s=area1, c="silver")
plt.scatter(pc1_exist_BRAF, pc2_exist_BRAF, label="train data", s=area2_BRAF, c=target_color1)
plt.scatter(pc1_exist_EGFR, pc2_exist_EGFR, label="train data", s=area2_EGFR, c=target_color2)
plt.scatter(pc1_exist_BRD4, pc2_exist_BRD4, label="train data", s=area2_BRD4, c=target_color3)
plt.scatter(pc1_exist_PARP, pc2_exist_PARP, label="train data", s=area2_PARP, c=target_color4)


plt.xlabel(u'Drug structure\n embedding(PC1) ', fontsize=55, labelpad=18.5)
plt.ylabel(u'Drug structure embedding(PC2) ', fontsize=55, labelpad=28.5)

# plt.xticks([-1.0, 0.0, 1.0], [-1.0, 0.0, 1.0], fontsize=35)
# plt.yticks([-1.0, 0.0, 1.0], [-1.0, 0.0, 1.0], fontsize=35)

plt.xticks([])
plt.yticks([])

ax = plt.gca()
ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2)
ax.spines['right'].set_linewidth(0)
ax.spines['top'].set_linewidth(0)

plt.savefig('../img/drug_pc.png', bbox_inches='tight')
plt.close()