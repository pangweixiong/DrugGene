import matplotlib.pyplot as plt
from scipy import stats
import numpy as np


con_list = []
mu_list = []
con_data = open("../data/pearson_con.txt")
for line in con_data:
    line = line.rstrip().split()
    con_list.append(float(line[0]))

con_data.close()
# *******
mu_data = open("../data/pearson_exp.txt")
# mu_data = open("../drug_res/pearson_mu.txt")
for line in mu_data:
    line = line.rstrip().split()
    mu_list.append(float(line[0]))

mu_data.close()

# print(con_list)
# print(mu_list)

con_than_mu = 0
for i in range(len(mu_list)):
    if con_list[i] > mu_list[i]:
        con_than_mu += 1
# print(con_than_mu)

from scipy.stats import gaussian_kde

mu_list = np.array(mu_list)
con_list = np.array(con_list)

xy = np.vstack([mu_list, con_list])  #  将两个维度的数据叠加
z = gaussian_kde(xy)(xy)

idx = z.argsort()
mu_list, con_list, z = mu_list[idx], con_list[idx], z[idx]
import matplotlib.ticker as ticker

plt.figure(figsize=(15, 10), dpi=100)
# fig, ax=plt.subplots(figsize=(10, 10), dpi=100)
plt.plot([-0.8, 1.0], [-0.8, 1.0], color='black', linewidth=3, label="best line")
plt.scatter(mu_list, con_list, c=z, label="train data", s=50, cmap='RdYlGn_r')
cb = plt.colorbar()
cb.ax.tick_params(labelsize=33, width=2)

tick_locator = ticker.MaxNLocator(nbins=5)  # colorbar上的刻度值个数
cb.locator = tick_locator
cb.update_ticks()

plt.xlabel(u'Correlation with truth by expBox ', fontsize=35)
plt.ylabel(u'Correlation with truth by DrugGene ', fontsize=35, labelpad=15)

plt.xticks([-0.4, 0.0, 0.4], [-0.4, 0.0, 0.4], fontsize=35)
plt.yticks([-0.4, 0.0, 0.4], [-0.4, 0.0, 0.4], fontsize=35)
# plt.xticks([-0.8, -0.4, 0.0, 0.4, 0.8], [-0.8, -0.4, 0.0, 0.4, 0.8], fontsize=35)
# plt.yticks([-0.8, -0.4, 0.0, 0.4, 0.8], [-0.8, -0.4, 0.0, 0.4, 0.8], fontsize=35)
plt.tick_params(width=2)

ax = plt.gca()
ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2)
ax.spines['right'].set_linewidth(0)
ax.spines['top'].set_linewidth(0)

plt.text(0.50, -0.7, r'p < 0.1',
         family='Times New Roman',  # 标注文本字体
         fontsize=30,  # 文本大小
         fontweight='bold',  # 字体粗细
         color='black'  # 文本颜色
         )

plt.savefig('../img/desity_exp.png', bbox_inches='tight')

sample1 = np.asarray(mu_list)
sample2 = np.asarray(con_list)
r = stats.ttest_ind(sample1, sample2)
