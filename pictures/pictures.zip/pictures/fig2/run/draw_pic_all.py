import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
import scipy.stats
import numpy as np

observed = []
predict = []
dc = []
test_data = open("../data/drug_test_update.txt")
dc_data = open("../data/drug_mutation.predict")
pre_data = open("../data/drug_concatenate.predict")
for line in test_data:
    line = line.rstrip().split()
    observed.append(round(float(line[2]), 5))

for line in pre_data:
    line = line.rstrip().split()
    # predict.append(round(float(line[0]), 5) * 10)
    predict.append(round(float(line[0]), 5))

for line in dc_data:
    line = line.rstrip().split()
    dc.append(round(float(line[0]), 5) * 5)

pre_data.close()
test_data.close()

# print("concatenate_pearson", scipy.stats.pearsonr(observed, predict)[0])
# print("concatenate_pearson", scipy.stats.pearsonr(observed, dc)[0])

np_arr_pre = []
for i in range(len(predict)):
    temp = []
    temp.append(predict[i])
    np_arr_pre.append(temp)

min_max_scaler = MinMaxScaler(feature_range=(0.2, 1.4))
pre_result = min_max_scaler.fit_transform(np.array(np_arr_pre))
# print(pre_result)

# np_arr_dc = []
# for i in range(len(dc)):
#     temp = []
#     temp.append(dc[i])
#     np_arr_dc.append(temp)
#
# min_max_scaler = MinMaxScaler(feature_range=(0.2, 1.4))
# dc_result = min_max_scaler.fit_transform(np.array(np_arr_dc))

plt.figure(figsize=(15, 10), dpi=100)
# plt.scatter(observed, predict, color='red', label="train data")

# fig, ax = plt.subplots()
# ax.spines['right'].set_visible(False)
# ax.spines['top'].set_visible(False)

area = [15] * len(observed)
plt.scatter(observed, dc, color='blue', label="train data", s=area)
plt.scatter(observed, pre_result, color='red', label="train data", s=area, marker='^')

plt.xlabel(u'Observed AUC ', fontsize=33)
plt.ylabel(u'Predictd AUC ', fontsize=33, labelpad=18.5)

plt.plot([0.0, 1.2], [0.2, 1.4], color='red', linewidth=8, label="best line")
plt.plot([0.05, 1.1], [0.2, 1.4], color='blue', linewidth=8, label="best line")


# plt.plot([0.0, 1.2], [0.2, 1.4], color='black', linewidth=8, label="best line")

plt.xticks([0.0, 0.4, 0.8, 1.2], [0.0, 0.4, 0.8, 1.2], fontsize=30)
plt.yticks([0.2, 0.6, 1.0, 1.4], [0.2, 0.6, 1.0, 1.4], fontsize=30)
plt.tick_params(width=2)

plt.text(0.0, 1.41, r'DrugGene ρ=0.73 p<0.0001',
         family='Times New Roman',  # 标注文本字体
         fontsize=27,  # 文本大小
         fontweight='bold',  # 字体粗细
         color='red'  # 文本颜色
         )

plt.text(0.0, 1.31, r'DrugCell ρ=0.69 p<0.0001',
         family='Times New Roman',  # 标注文本字体
         fontsize=27,  # 文本大小
         fontweight='bold',  # 字体粗细
         color='blue'  # 文本颜色
         )

ax = plt.gca()
ax.spines['bottom'].set_linewidth(1.1)
ax.spines['left'].set_linewidth(1.1)
ax.spines['right'].set_linewidth(0)
ax.spines['top'].set_linewidth(0)

plt.savefig('../img/pearson_all.png', bbox_inches='tight')



