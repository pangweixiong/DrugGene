import numpy as np
import matplotlib.pyplot as plt
from scipy import stats


labels = 'DrugGene', 'DrugCell', 'expBox', 'cnvBox'
multi_input = [0.730047, 0.723290, 0.727364, 0.727773, 0.707436, 0.719551, 0.715721, 0.713437, 0.716941, 0.714076]
dc = [0.690825, 0.702259, 0.686374, 0.683695, 0.680843, 0.698379, 0.686770, 0.676734, 0.678649, 0.678270]
expression = [0.690525, 0.701162, 0.682354, 0.684655, 0.680235, 0.696359, 0.684450, 0.674533, 0.679650, 0.679670]
copy_number = [0.690825, 0.700149, 0.683472, 0.682255, 0.680253, 0.697448, 0.685760, 0.676478, 0.678614, 0.678878]

plt.grid(False)  # 显示网格

fig, ax = plt.subplots(figsize=(13, 10), dpi=100)
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
color=['k', 'g', 'r', 'deepskyblue']
bp = plt.boxplot([multi_input, dc, expression, copy_number],
            medianprops={'color': 'blue', 'linewidth': '5'},
            meanline=True,
            showmeans=True,
            meanprops={'color': 'red', 'ls': '--', 'linewidth': '5'},
            flierprops={"marker": "o", "markerfacecolor": "red", "markersize": 10},
            labels=labels,
            patch_artist=True,
            boxprops=dict(facecolor='silver'),
            capprops={'color': 'black', 'linewidth': 5, 'linestyle': '-'},
            whiskerprops=dict(linewidth=5))

# color=['k', 'g', 'r', 'deepskyblue'] # 有多少box就对应设置多少颜色
for box,c in zip(bp['boxes'], color):
    # 箱体边框颜色
    box.set(linewidth=5)
    # 箱体内部填充颜色

plt.yticks(np.arange(0.66, 0.741, 0.02), fontsize=32)
plt.xticks(fontsize=30)
plt.tick_params(width=2)

plt.ylabel("Pearson correlation", fontsize=35, labelpad=15)
plt.xlabel("Method ", fontsize=35)

ax = plt.gca()
ax.spines['bottom'].set_linewidth(2)
ax.spines['left'].set_linewidth(2)
ax.spines['right'].set_linewidth(0)
ax.spines['top'].set_linewidth(0)

sample1 = np.asarray(multi_input)
sample2 = np.asarray(dc)
r = stats.ttest_ind(sample1, sample2)

sample1 = np.asarray(multi_input)
sample2 = np.asarray(expression)
r = stats.ttest_ind(sample1, sample2)

sample1 = np.asarray(multi_input)
sample2 = np.asarray(copy_number)
r = stats.ttest_ind(sample1, sample2)

plt.savefig('../img/boxplot.png', bbox_inches='tight')
